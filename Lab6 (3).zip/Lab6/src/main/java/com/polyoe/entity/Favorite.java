package com.polyoe.entity;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(
    name = "Favorites",
    uniqueConstraints = {
        // VideoId + UserId phải duy nhất (mỗi user chỉ like 1 video 1 lần)
        @UniqueConstraint(columnNames = {"VideoId", "UserId"})
    }
)
public class Favorite {

    // Id tự tăng (IDENTITY)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id")
    private Long id;

    // Nhiều Favorite thuộc về 1 User – FK cột UserId
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "UserId", referencedColumnName = "Id",
                foreignKey = @ForeignKey(
                    name = "FK_Favorites_Users",
                    foreignKeyDefinition = "FOREIGN KEY (UserId) REFERENCES Users(Id) ON DELETE NO ACTION"
                ))
    private User user;

    // Nhiều Favorite thuộc về 1 Video – FK cột VideoId
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "VideoId", referencedColumnName = "Id",
                foreignKey = @ForeignKey(
                    name = "FK_Favorites_Videos",
                    foreignKeyDefinition = "FOREIGN KEY (VideoId) REFERENCES Videos(Id) ON DELETE NO ACTION"
                ))
    private Video video;

    @Temporal(TemporalType.DATE)
    @Column(name = "LikeDate")
    private Date likeDate = new Date();

    // ==================== Constructors ====================

    public Favorite() {}

    public Favorite(User user, Video video) {
        this.user  = user;
        this.video = video;
    }

    // ==================== Getters & Setters ====================

    public Long getId()                  { return id; }
    public void setId(Long id)           { this.id = id; }

    public User getUser()                { return user; }
    public void setUser(User user)       { this.user = user; }

    public Video getVideo()              { return video; }
    public void setVideo(Video video)    { this.video = video; }

    public Date getLikeDate()            { return likeDate; }
    public void setLikeDate(Date d)      { this.likeDate = d; }

    @Override
    public String toString() {
        return "Favorite{id=" + id + ", user=" + (user != null ? user.getId() : null)
             + ", video=" + (video != null ? video.getId() : null) + "}";
    }
}
