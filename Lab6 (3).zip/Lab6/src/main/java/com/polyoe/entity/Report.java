package com.polyoe.entity;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Date;

// ===== Bài 4: Stored Procedure =====
@NamedStoredProcedureQueries({
    @NamedStoredProcedureQuery(
        name          = "Report.favoriteByYear",
        procedureName = "spFavoriteByYear",
        parameters    = {
            @StoredProcedureParameter(name = "Year", type = Integer.class,
                                      mode = ParameterMode.IN)
        },
        resultClasses = { Report.class }
    )
})

/**
 * Không phải bảng thật – dùng để nắm giữ kết quả truy vấn tổng hợp (Bài 2.5 & Bài 4.2).
 * @Entity cần thiết để JPA nhận diện constructor expression trong JPQL.
 */
@Entity
public class Report implements Serializable {

    // group = video title (hoặc bất kỳ giá trị group nào)
    @Id
    private Serializable group;

    private Long  likes;
    private Date  newest;
    private Date  oldest;

    // ==================== Constructors ====================

    public Report() {}

    /** Constructor dùng trong JPQL: new Report(o.video.title, count(o), max(...), min(...)) */
    public Report(Serializable group, Long likes, Date newest, Date oldest) {
        this.group  = group;
        this.likes  = likes;
        this.newest = newest;
        this.oldest = oldest;
    }

    // ==================== Getters & Setters ====================

    public Serializable getGroup()           { return group; }
    public void setGroup(Serializable group) { this.group = group; }

    public Long getLikes()                   { return likes; }
    public void setLikes(Long likes)         { this.likes = likes; }

    public Date getNewest()                  { return newest; }
    public void setNewest(Date newest)       { this.newest = newest; }

    public Date getOldest()                  { return oldest; }
    public void setOldest(Date oldest)       { this.oldest = oldest; }
}
