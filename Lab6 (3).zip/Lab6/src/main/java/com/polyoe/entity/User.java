package com.polyoe.entity;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "Users")
public class User {

    @Id
    @Column(name = "Id", length = 20)
    private String id;

    @Column(name = "Password", length = 50)
    private String password;

    @Column(name = "Fullname", length = 50)
    private String fullname;

    @Column(name = "Email", length = 50)
    private String email;

    @Column(name = "Admin")
    private Boolean admin = false;

    // Một User có nhiều Favorite
    // mappedBy = tên field "user" bên lớp Favorite
    // cascade REMOVE bị tắt => không xóa cascade, RESTRICT ở DB sẽ chặn
    @OneToMany(mappedBy = "user", fetch = FetchType.LAZY)
    private List<Favorite> favorites;

    // ==================== Constructors ====================

    public User() {}

    public User(String id, String password, String fullname, String email, Boolean admin) {
        this.id       = id;
        this.password = password;
        this.fullname = fullname;
        this.email    = email;
        this.admin    = admin;
    }

    // ==================== Getters & Setters ====================

    public String getId()                  { return id; }
    public void setId(String id)           { this.id = id; }

    public String getPassword()            { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getFullname()            { return fullname; }
    public void setFullname(String fullname) { this.fullname = fullname; }

    public String getEmail()               { return email; }
    public void setEmail(String email)     { this.email = email; }

    public Boolean getAdmin()              { return admin; }
    public void setAdmin(Boolean admin)    { this.admin = admin; }

    public List<Favorite> getFavorites()            { return favorites; }
    public void setFavorites(List<Favorite> favorites) { this.favorites = favorites; }

    @Override
    public String toString() {
        return "User{id='" + id + "', fullname='" + fullname + "'}";
    }
}
