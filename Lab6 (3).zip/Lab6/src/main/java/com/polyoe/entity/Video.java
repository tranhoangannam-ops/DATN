package com.polyoe.entity;

import jakarta.persistence.*;
import java.util.List;

// ===== Bài 3: @NamedQuery =====
@NamedQueries({
    // Tìm video yêu thích theo từ khóa trong title
    @NamedQuery(
        name  = "Video.findByKeyword",
        query = "SELECT DISTINCT o.video FROM Favorite o"
              + " WHERE o.video.title LIKE :keyword"
    ),
    // Tìm video yêu thích theo user id
    @NamedQuery(
        name  = "Video.findByUser",
        query = "SELECT o.video FROM Favorite o"
              + " WHERE o.user.id = :id"
    ),
    // Tìm video được thích trong khoảng ngày
    @NamedQuery(
        name  = "Video.findInRange",
        query = "SELECT DISTINCT o.video FROM Favorite o"
              + " WHERE o.likeDate BETWEEN :min AND :max"
    ),
    // Tìm video được thích trong danh sách tháng
    @NamedQuery(
        name  = "Video.findInMonths",
        query = "SELECT DISTINCT o.video FROM Favorite o"
              + " WHERE month(o.likeDate) IN (:months)"
    )
})

// ===== Bài 4: @NamedNativeQuery – 10 video ngẫu nhiên bằng SQL thuần =====
@NamedNativeQueries({
    @NamedNativeQuery(
        name        = "Report.random10",
        query       = "SELECT TOP 10 * FROM Videos ORDER BY NEWID()",
        resultClass = Video.class
    )
})

@Entity
@Table(name = "Videos")
public class Video {

    @Id
    @Column(name = "Id", length = 11)
    private String id;

    @Column(name = "Title", length = 50)
    private String title;

    @Column(name = "Poster", length = 50)
    private String poster;

    @Column(name = "Description", columnDefinition = "nvarchar(MAX)")
    private String description;

    @Column(name = "Views")
    private Integer views = 0;

    @Column(name = "Active")
    private Boolean active = true;

    // Một Video có nhiều Favorite
    @OneToMany(mappedBy = "video", fetch = FetchType.LAZY)
    private List<Favorite> favorites;

    // ==================== Constructors ====================

    public Video() {}

    public Video(String id, String title, String poster, String description) {
        this.id          = id;
        this.title       = title;
        this.poster      = poster;
        this.description = description;
    }

    // ==================== Getters & Setters ====================

    public String getId()                   { return id; }
    public void setId(String id)            { this.id = id; }

    public String getTitle()                { return title; }
    public void setTitle(String title)      { this.title = title; }

    public String getPoster()               { return poster; }
    public void setPoster(String poster)    { this.poster = poster; }

    public String getDescription()          { return description; }
    public void setDescription(String d)    { this.description = d; }

    public Integer getViews()               { return views; }
    public void setViews(Integer views)     { this.views = views; }

    public Boolean getActive()              { return active; }
    public void setActive(Boolean active)   { this.active = active; }

    public List<Favorite> getFavorites()             { return favorites; }
    public void setFavorites(List<Favorite> favs)    { this.favorites = favs; }

    @Override
    public String toString() {
        return "Video{id='" + id + "', title='" + title + "'}";
    }
}
