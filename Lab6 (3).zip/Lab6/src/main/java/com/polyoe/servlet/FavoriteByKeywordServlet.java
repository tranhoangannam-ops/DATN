package com.polyoe.servlet;

import com.polyoe.entity.Video;
import com.polyoe.util.EMUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.List;

/**
 * Bài 2.2 – Tìm video được yêu thích có title chứa từ khóa.
 * Bài 3.1 – Dùng @NamedQuery "Video.findByKeyword".
 *
 * GET /favorite-by-keyword?keyword=java            → JPQL trực tiếp
 * GET /favorite-by-keyword?keyword=java&namedQuery=true → @NamedQuery
 */
@WebServlet("/favorite-by-keyword")
public class FavoriteByKeywordServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        String keyword  = req.getParameter("keyword");
        String useNamed = req.getParameter("namedQuery");

        EntityManager em = EMUtil.getEntityManager();
        try {
            if (keyword != null && !keyword.isBlank()) {
                String likeParam = "%" + keyword.trim() + "%";

                List<Video> list;
                if ("true".equals(useNamed)) {
                    // ===== Bài 3.1: @NamedQuery =====
                    TypedQuery<Video> query =
                        em.createNamedQuery("Video.findByKeyword", Video.class);
                    query.setParameter("keyword", likeParam);
                    list = query.getResultList();
                    req.setAttribute("mode", "NamedQuery");
                } else {
                    // ===== Bài 2.2: JPQL trực tiếp =====
                    String jpql = "SELECT DISTINCT o.video FROM Favorite o"
                                + " WHERE o.video.title LIKE :keyword";
                    TypedQuery<Video> query = em.createQuery(jpql, Video.class);
                    query.setParameter("keyword", likeParam);
                    list = query.getResultList();
                    req.setAttribute("mode", "JPQL");
                }

                req.setAttribute("videos", list);
                req.setAttribute("keyword", keyword);
            }
        } catch (Exception e) {
            req.setAttribute("error", "Lỗi truy vấn: " + e.getMessage());
            e.printStackTrace();
        } finally {
            em.close();
        }

        req.getRequestDispatcher("/WEB-INF/views/favorite-by-keyword.jsp")
           .forward(req, resp);
    }
}
