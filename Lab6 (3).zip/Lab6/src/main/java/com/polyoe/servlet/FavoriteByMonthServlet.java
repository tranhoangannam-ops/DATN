package com.polyoe.servlet;

import com.polyoe.entity.Video;
import com.polyoe.util.EMUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Bài 3.4 – Tìm video được thích trong danh sách tháng.
 * Dùng @NamedQuery "Video.findInMonths" với tham số List<Integer>.
 * GET /favorite-by-month?month=1&month=3&month=11
 */
@WebServlet("/favorite-by-month")
public class FavoriteByMonthServlet extends HttpServlet {

    private static final String[] MONTH_NAMES = {
        "", "Tháng 1", "Tháng 2", "Tháng 3", "Tháng 4",
        "Tháng 5", "Tháng 6", "Tháng 7", "Tháng 8",
        "Tháng 9", "Tháng 10", "Tháng 11", "Tháng 12"
    };

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        String[] values = req.getParameterValues("month");

        EntityManager em = EMUtil.getEntityManager();
        try {
            if (values != null && values.length > 0) {

                // ===== Bài 3.4: tham số IN (:months) phải là List<Integer> =====
                List<Integer> months = new ArrayList<>();
                for (String m : values) {
                    months.add(Integer.valueOf(m));
                }

                TypedQuery<Video> query =
                    em.createNamedQuery("Video.findInMonths", Video.class);
                query.setParameter("months", months);
                List<Video> list = query.getResultList();

                req.setAttribute("videos",      list);
                req.setAttribute("months",      months);
                req.setAttribute("monthNames",  MONTH_NAMES);
            }
        } catch (Exception e) {
            req.setAttribute("error", "Lỗi truy vấn: " + e.getMessage());
            e.printStackTrace();
        } finally {
            em.close();
        }

        req.getRequestDispatcher("/WEB-INF/views/favorite-by-month.jsp")
           .forward(req, resp);
    }
}
