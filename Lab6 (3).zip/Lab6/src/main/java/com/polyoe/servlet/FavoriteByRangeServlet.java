package com.polyoe.servlet;

import com.polyoe.entity.Video;
import com.polyoe.util.EMUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

/**
 * Bài 3.3 – Tìm video được thích trong khoảng thời gian (min date – max date).
 * Dùng @NamedQuery "Video.findInRange".
 * GET /favorite-by-range?from=2024-01-01&to=2024-06-30
 */
@WebServlet("/favorite-by-range")
public class FavoriteByRangeServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        String fromStr = req.getParameter("from");
        String toStr   = req.getParameter("to");

        EntityManager em = EMUtil.getEntityManager();
        try {
            if (fromStr != null && !fromStr.isBlank()
             && toStr   != null && !toStr.isBlank()) {

                // Chuyển String → java.sql.Date (tương thích TemporalType.DATE)
                java.sql.Date minDate = java.sql.Date.valueOf(fromStr.trim());
                java.sql.Date maxDate = java.sql.Date.valueOf(toStr.trim());

                // ===== Bài 3.3: @NamedQuery BETWEEN =====
                TypedQuery<Video> query =
                    em.createNamedQuery("Video.findInRange", Video.class);
                query.setParameter("min", minDate,
                                   jakarta.persistence.TemporalType.DATE);
                query.setParameter("max", maxDate,
                                   jakarta.persistence.TemporalType.DATE);
                List<Video> list = query.getResultList();

                req.setAttribute("videos",  list);
                req.setAttribute("fromStr", fromStr);
                req.setAttribute("toStr",   toStr);
            }
        } catch (Exception e) {
            req.setAttribute("error", "Lỗi truy vấn: " + e.getMessage());
            e.printStackTrace();
        } finally {
            em.close();
        }

        req.getRequestDispatcher("/WEB-INF/views/favorite-by-range.jsp")
           .forward(req, resp);
    }
}
