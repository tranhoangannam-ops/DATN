package com.polyoe.servlet;

import com.polyoe.entity.Favorite;
import com.polyoe.entity.User;
import com.polyoe.entity.Video;
import com.polyoe.util.EMUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

/**
 * Bài 2.1 – Tìm các video yêu thích theo người sử dụng (nhập user id).
 * Bài 3.2 – Dùng @NamedQuery "Video.findByUser".
 *
 * GET  /favorite-by-user           → hiển thị form
 * GET  /favorite-by-user?username= → tìm kiếm
 * GET  /favorite-by-user?username=&namedQuery=true → dùng @NamedQuery
 */
@WebServlet("/favorite-by-user")
public class FavoriteByUserServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        String username    = req.getParameter("username");
        String useNamed    = req.getParameter("namedQuery"); // "true" dùng NamedQuery

        EntityManager em = EMUtil.getEntityManager();
        try {
            if (username != null && !username.isBlank()) {

                // --- Lấy thông tin User ---
                User user = em.find(User.class, username.trim());
                if (user == null) {
                    req.setAttribute("error", "Không tìm thấy user: " + username);
                } else {
                    req.setAttribute("user", user);

                    if ("true".equals(useNamed)) {
                        // ===== Bài 3.2: @NamedQuery =====
                        TypedQuery<Video> query =
                            em.createNamedQuery("Video.findByUser", Video.class);
                        query.setParameter("id", username.trim());
                        List<Video> videos = query.getResultList();
                        req.setAttribute("videos", videos);
                        req.setAttribute("mode", "NamedQuery");
                    } else {
                        // ===== Bài 2.1: JPQL thông qua quan hệ =====
                        List<Favorite> favorites = user.getFavorites();
                        req.setAttribute("favorites", favorites);
                        req.setAttribute("mode", "JPQL");
                    }
                }
                req.setAttribute("username", username);
            }
        } catch (Exception e) {
            req.setAttribute("error", "Lỗi truy vấn: " + e.getMessage());
            e.printStackTrace();
        } finally {
            em.close();
        }

        req.getRequestDispatcher("/WEB-INF/views/favorite-by-user.jsp")
           .forward(req, resp);
    }
}
