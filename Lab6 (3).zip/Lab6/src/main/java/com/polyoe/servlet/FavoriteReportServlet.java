package com.polyoe.servlet;

import com.polyoe.entity.Report;
import com.polyoe.util.EMUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.List;

/**
 * Bài 2.5 – Tổng hợp số lượt thích từng video.
 * Kết quả: (video title, số lượt thích, ngày thích lâu nhất, ngày thích mới nhất)
 * Sử dụng JPQL GROUP BY + constructor expression new Report(...)
 * GET /favorite-report
 */
@WebServlet("/favorite-report")
public class FavoriteReportServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        EntityManager em = EMUtil.getEntityManager();
        try {
            // ===== Bài 2.5: GROUP BY + constructor expression =====
            String jpql = "SELECT new com.polyoe.entity.Report("
                        + "  o.video.title, count(o), max(o.likeDate), min(o.likeDate)"
                        + ") FROM Favorite o GROUP BY o.video.title"
                        + " ORDER BY count(o) DESC";

            TypedQuery<Report> query = em.createQuery(jpql, Report.class);
            List<Report> list = query.getResultList();
            req.setAttribute("reports", list);

        } catch (Exception e) {
            req.setAttribute("error", "Lỗi truy vấn: " + e.getMessage());
            e.printStackTrace();
        } finally {
            em.close();
        }

        req.getRequestDispatcher("/WEB-INF/views/favorite-report.jsp")
           .forward(req, resp);
    }
}
