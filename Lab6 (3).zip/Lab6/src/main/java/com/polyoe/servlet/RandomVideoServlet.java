package com.polyoe.servlet;

import com.polyoe.entity.Video;
import com.polyoe.util.EMUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.List;

/**
 * Bài 4.1 – Truy vấn và hiển thị 10 video ngẫu nhiên.
 * Dùng @NamedNativeQuery "Report.random10" (SQL thuần: SELECT TOP 10 … ORDER BY NEWID()).
 * GET /random-videos
 */
@WebServlet("/random-videos")
public class RandomVideoServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        EntityManager em = EMUtil.getEntityManager();
        try {
            // ===== Bài 4.1: @NamedNativeQuery =====
            @SuppressWarnings("unchecked")
            Query query = em.createNamedQuery("Report.random10");
            List<Video> list = query.getResultList();
            req.setAttribute("videos", list);

        } catch (Exception e) {
            req.setAttribute("error", "Lỗi truy vấn: " + e.getMessage());
            e.printStackTrace();
        } finally {
            em.close();
        }

        req.getRequestDispatcher("/WEB-INF/views/random-videos.jsp")
           .forward(req, resp);
    }
}
