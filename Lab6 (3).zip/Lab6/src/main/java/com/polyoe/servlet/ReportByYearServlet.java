package com.polyoe.servlet;

import com.polyoe.entity.Report;
import com.polyoe.util.EMUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.StoredProcedureQuery;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.List;

/**
 * Bài 4.2 – Tổng hợp số lượt thích từng video theo năm.
 * Dùng @NamedStoredProcedureQuery "Report.favoriteByYear" → spFavoriteByYear(@Year INT).
 * GET /report-by-year?year=2024
 */
@WebServlet("/report-by-year")
public class ReportByYearServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        String yearStr = req.getParameter("year");

        EntityManager em = EMUtil.getEntityManager();
        try {
            if (yearStr != null && !yearStr.isBlank()) {
                Integer year = Integer.valueOf(yearStr.trim());

                // ===== Bài 4.2: Stored Procedure =====
                StoredProcedureQuery query =
                    em.createNamedStoredProcedureQuery("Report.favoriteByYear");
                query.setParameter("Year", year);

                @SuppressWarnings("unchecked")
                List<Report> list = query.getResultList();
                req.setAttribute("reports", list);
                req.setAttribute("year",    year);
            }
        } catch (Exception e) {
            req.setAttribute("error", "Lỗi truy vấn: " + e.getMessage());
            e.printStackTrace();
        } finally {
            em.close();
        }

        req.getRequestDispatcher("/WEB-INF/views/report-by-year.jsp")
           .forward(req, resp);
    }
}
