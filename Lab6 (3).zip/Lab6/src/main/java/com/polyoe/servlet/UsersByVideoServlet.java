package com.polyoe.servlet;

import com.polyoe.entity.User;
import com.polyoe.util.EMUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.List;

/**
 * Bài 2.3 – Tìm những người sử dụng thích video (nhập video id).
 * GET /users-by-video?videoId=VID00000001
 */
@WebServlet("/users-by-video")
public class UsersByVideoServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        String videoId = req.getParameter("videoId");

        EntityManager em = EMUtil.getEntityManager();
        try {
            if (videoId != null && !videoId.isBlank()) {
                // ===== Bài 2.3: JPQL SELECT o.user =====
                String jpql = "SELECT o.user FROM Favorite o WHERE o.video.id = :vid";
                TypedQuery<User> query = em.createQuery(jpql, User.class);
                query.setParameter("vid", videoId.trim());
                List<User> users = query.getResultList();

                req.setAttribute("users",   users);
                req.setAttribute("videoId", videoId);
            }
        } catch (Exception e) {
            req.setAttribute("error", "Lỗi truy vấn: " + e.getMessage());
            e.printStackTrace();
        } finally {
            em.close();
        }

        req.getRequestDispatcher("/WEB-INF/views/users-by-video.jsp")
           .forward(req, resp);
    }
}
