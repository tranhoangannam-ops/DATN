package com.polyoe.servlet;

import com.polyoe.entity.Video;
import com.polyoe.util.EMUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.List;

/**
 * Bài 2.4 – Hiển thị tất cả video KHÔNG có hoặc CÓ yêu thích.
 * GET /video-by-favorite             → form (mặc định Not Favorite)
 * GET /video-by-favorite?favorite=false → video chưa được ai thích
 * GET /video-by-favorite?favorite=true  → video đã được thích
 */
@WebServlet("/video-by-favorite")
public class VideoByFavoriteServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        String favParam = req.getParameter("favorite");

        EntityManager em = EMUtil.getEntityManager();
        try {
            if (favParam != null) {
                // ===== Bài 2.4: IS EMPTY / IS NOT EMPTY =====
                boolean favorite = Boolean.parseBoolean(favParam);

                String jpql = favorite
                    ? "SELECT o FROM Video o WHERE o.favorites IS NOT EMPTY"
                    : "SELECT o FROM Video o WHERE o.favorites IS EMPTY";

                TypedQuery<Video> query = em.createQuery(jpql, Video.class);
                List<Video> list = query.getResultList();

                req.setAttribute("videos",   list);
                req.setAttribute("favorite", favorite);
            }
        } catch (Exception e) {
            req.setAttribute("error", "Lỗi truy vấn: " + e.getMessage());
            e.printStackTrace();
        } finally {
            em.close();
        }

        req.getRequestDispatcher("/WEB-INF/views/video-by-favorite.jsp")
           .forward(req, resp);
    }
}
