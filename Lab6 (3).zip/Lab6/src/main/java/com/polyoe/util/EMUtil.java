package com.polyoe.util;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

/**
 * Singleton EntityManagerFactory.
 * Dùng chung 1 factory cho toàn ứng dụng, mỗi request tạo 1 EntityManager riêng.
 */
public class EMUtil {

    private static final String PERSISTENCE_UNIT = "PolyOEPU";
    private static EntityManagerFactory emf;

    // Khởi tạo factory khi class được load lần đầu
    static {
        try {
            emf = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT);
        } catch (Exception e) {
            System.err.println("[EMUtil] Không thể tạo EntityManagerFactory: " + e.getMessage());
            throw new RuntimeException("Lỗi khởi tạo JPA EntityManagerFactory", e);
        }
    }

    private EMUtil() {}

    /** Lấy EntityManager mới cho mỗi request */
    public static EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    /** Đóng factory khi ứng dụng shutdown */
    public static void close() {
        if (emf != null && emf.isOpen()) {
            emf.close();
        }
    }
}
