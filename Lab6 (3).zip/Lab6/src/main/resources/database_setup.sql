-- ============================================================
-- Script tạo CSDL PolyOE cho Lab 06
-- Chạy trong SQL Server Management Studio (SSMS)
-- ============================================================

USE master;
GO

-- Tạo database nếu chưa có
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'PolyOE')
BEGIN
    CREATE DATABASE PolyOE;
    PRINT 'Database PolyOE created.';
END
GO

USE PolyOE;
GO

-- ============================================================
-- 1. Bảng Users
-- ============================================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Users')
BEGIN
    CREATE TABLE Users (
        Id       NVARCHAR(20)  NOT NULL PRIMARY KEY,
        Password NVARCHAR(50)  NOT NULL,
        Fullname NVARCHAR(50),
        Email    NVARCHAR(50),
        Admin    BIT           DEFAULT 0
    );
    PRINT 'Table Users created.';
END
GO

-- ============================================================
-- 2. Bảng Videos
-- ============================================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Videos')
BEGIN
    CREATE TABLE Videos (
        Id          CHAR(11)       NOT NULL PRIMARY KEY,
        Title       NVARCHAR(50)   NOT NULL,
        Poster      NVARCHAR(50),
        Description NVARCHAR(MAX),
        Active      BIT            DEFAULT 1,
        Views       INT            DEFAULT 0
    );
    PRINT 'Table Videos created.';
END
GO

-- ============================================================
-- 3. Bảng Favorites (bảng kết hợp)
-- ============================================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Favorites')
BEGIN
    CREATE TABLE Favorites (
        Id       BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        VideoId  CHAR(11)             NOT NULL,
        UserId   NVARCHAR(20)         NOT NULL,
        LikeDate DATE                 DEFAULT GETDATE(),

        -- Ràng buộc: mỗi user chỉ được like mỗi video 1 lần
        CONSTRAINT UQ_Favorites_Video_User UNIQUE (VideoId, UserId),

        -- Không cho phép xóa Video nếu đã có Favorite (ON DELETE NO ACTION)
        CONSTRAINT FK_Favorites_Videos
            FOREIGN KEY (VideoId) REFERENCES Videos(Id)
            ON DELETE NO ACTION ON UPDATE CASCADE,

        -- Không cho phép xóa User nếu đã có Favorite
        CONSTRAINT FK_Favorites_Users
            FOREIGN KEY (UserId) REFERENCES Users(Id)
            ON DELETE NO ACTION ON UPDATE CASCADE
    );
    PRINT 'Table Favorites created.';
END
GO

-- ============================================================
-- 4. Dữ liệu mẫu – Users
-- ============================================================
IF NOT EXISTS (SELECT * FROM Users WHERE Id = 'admin')
BEGIN
    INSERT INTO Users (Id, Password, Fullname, Email, Admin) VALUES
    ('admin',  '123456', N'Quản Trị Viên', 'admin@polyoe.vn',   1),
    ('user01', '123456', N'Nguyễn Văn An', 'an@polyoe.vn',      0),
    ('user02', '123456', N'Trần Thị Bình', 'binh@polyoe.vn',    0),
    ('user03', '123456', N'Lê Hoàng Cường','cuong@polyoe.vn',   0),
    ('user04', '123456', N'Phạm Thị Dung', 'dung@polyoe.vn',    0);
    PRINT 'Sample Users inserted.';
END
GO

-- ============================================================
-- 5. Dữ liệu mẫu – Videos
-- ============================================================
IF NOT EXISTS (SELECT * FROM Videos WHERE Id = 'VID00000001')
BEGIN
    INSERT INTO Videos (Id, Title, Poster, Description, Active, Views) VALUES
    ('VID00000001', N'Lập Trình Java Căn Bản',     'java_basic.jpg',    N'Khóa học Java từ cơ bản đến nâng cao',  1, 1500),
    ('VID00000002', N'Học Spring Boot 3',           'spring_boot.jpg',   N'Spring Boot với Jakarta EE 10',          1, 2300),
    ('VID00000003', N'JPA & Hibernate Thực Chiến',  'jpa_hib.jpg',       N'Mapping entity, JPQL, Criteria API',     1, 870),
    ('VID00000004', N'React.js Cho Người Mới',      'react_js.jpg',      N'Frontend hiện đại với React',            1, 4100),
    ('VID00000005', N'Docker & Kubernetes Cơ Bản',  'docker_k8s.jpg',    N'Containerization và orchestration',      1, 760),
    ('VID00000006', N'SQL Server Từ A Đến Z',       'sqlserver.jpg',     N'T-SQL, Store Procedure, Index',          1, 1200),
    ('VID00000007', N'Thiết Kế UI/UX Với Figma',   'figma.jpg',         N'Prototype và design system',             0, 330),
    ('VID00000008', N'Python Data Science',          'python_ds.jpg',     N'Pandas, NumPy, Matplotlib',              1, 5500),
    ('VID00000009', N'DevOps CI/CD Pipeline',        'devops.jpg',        N'GitHub Actions, Jenkins, GitLab CI',     1, 980),
    ('VID00000010', N'Bảo Mật Web OWASP Top 10',    'security.jpg',      N'SQL Injection, XSS, CSRF và cách phòng',1, 2100);
    PRINT 'Sample Videos inserted.';
END
GO

-- ============================================================
-- 6. Dữ liệu mẫu – Favorites
-- ============================================================
IF NOT EXISTS (SELECT * FROM Favorites WHERE UserId = 'user01' AND VideoId = 'VID00000001')
BEGIN
    INSERT INTO Favorites (VideoId, UserId, LikeDate) VALUES
    ('VID00000001', 'user01', '2024-01-15'),
    ('VID00000002', 'user01', '2024-03-20'),
    ('VID00000003', 'user01', '2024-06-10'),
    ('VID00000001', 'user02', '2024-02-28'),
    ('VID00000004', 'user02', '2024-03-05'),
    ('VID00000005', 'user02', '2024-11-12'),
    ('VID00000002', 'user03', '2024-03-18'),
    ('VID00000006', 'user03', '2024-07-22'),
    ('VID00000008', 'user03', '2024-10-30'),
    ('VID00000003', 'user04', '2024-04-01'),
    ('VID00000009', 'user04', '2024-11-15'),
    ('VID00000010', 'user04', '2024-12-01');
    PRINT 'Sample Favorites inserted.';
END
GO

-- ============================================================
-- 7. Stored Procedure – spFavoriteByYear (Bài 4.2)
-- ============================================================
IF OBJECT_ID('spFavoriteByYear', 'P') IS NOT NULL
    DROP PROCEDURE spFavoriteByYear;
GO

CREATE PROCEDURE spFavoriteByYear
    @Year INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT
        v.Title          AS [Group],
        COUNT(f.Id)      AS [Likes],
        MAX(f.LikeDate)  AS [Newest],
        MIN(f.LikeDate)  AS [Oldest]
    FROM  Favorites f
    JOIN  Videos v ON v.Id = f.VideoId
    WHERE YEAR(f.LikeDate) = @Year
    GROUP BY v.Title
    ORDER BY [Likes] DESC;
END
GO

PRINT 'Stored Procedure spFavoriteByYear created.';
PRINT '=== PolyOE database setup complete! ===';
GO
