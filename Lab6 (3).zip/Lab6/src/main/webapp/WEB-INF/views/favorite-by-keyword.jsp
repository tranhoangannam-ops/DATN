<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Video yêu thích theo Keyword – PolyOE</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<nav>
    <a class="brand" href="${pageContext.request.contextPath}/index.jsp">🎬 PolyOE</a>
    <a href="${pageContext.request.contextPath}/favorite-by-user">Bài 2.1 / 3.2</a>
    <a href="${pageContext.request.contextPath}/favorite-by-keyword" class="active">Bài 2.2 / 3.1</a>
    <a href="${pageContext.request.contextPath}/users-by-video">Bài 2.3</a>
    <a href="${pageContext.request.contextPath}/video-by-favorite">Bài 2.4</a>
    <a href="${pageContext.request.contextPath}/favorite-report">Bài 2.5</a>
    <a href="${pageContext.request.contextPath}/favorite-by-range">Bài 3.3</a>
    <a href="${pageContext.request.contextPath}/favorite-by-month">Bài 3.4</a>
    <a href="${pageContext.request.contextPath}/random-videos">Bài 4.1</a>
    <a href="${pageContext.request.contextPath}/report-by-year">Bài 4.2</a>
</nav>

<div class="container">
    <div class="page-title">Bài 2.2 / 3.1 – Video yêu thích theo từ khóa</div>

    <div class="card">
        <h2>🔍 Tìm kiếm theo từ khóa trong Title</h2>
        <form method="get" action="${pageContext.request.contextPath}/favorite-by-keyword">
            <div class="form-row">
                <input type="text" name="keyword" placeholder="Keyword?"
                       value="${keyword}" required>
                <select name="namedQuery">
                    <option value="false" ${mode == 'JPQL' ? 'selected' : ''}>Bài 2.2 – JPQL trực tiếp</option>
                    <option value="true"  ${mode == 'NamedQuery' ? 'selected' : ''}>Bài 3.1 – @NamedQuery</option>
                </select>
                <button type="submit" class="btn">Search</button>
            </div>
        </form>
    </div>

    <c:if test="${not empty error}">
        <div class="alert alert-danger">${error}</div>
    </c:if>

    <c:if test="${not empty keyword}">
        <div class="card">
            <h2>🎬 Kết quả – từ khóa: "<strong>${keyword}</strong>"
                <small style="color:#888;font-weight:400">(${mode})</small>
            </h2>
            <c:choose>
                <c:when test="${empty videos}">
                    <div class="empty-state">Không tìm thấy video yêu thích nào khớp với từ khóa.</div>
                </c:when>
                <c:otherwise>
                    <table>
                        <thead>
                            <tr><th>Id</th><th>Title</th><th>Views</th><th>Active</th></tr>
                        </thead>
                        <tbody>
                            <c:forEach var="v" items="${videos}">
                                <tr>
                                    <td><code>${v.id}</code></td>
                                    <td>${v.title}</td>
                                    <td>${v.views}</td>
                                    <td>
                                        <span class="badge ${v.active ? 'badge-yes' : 'badge-no'}">
                                            ${v.active ? 'Yes' : 'No'}
                                        </span>
                                    </td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </c:otherwise>
            </c:choose>
        </div>
    </c:if>
</div>
</body>
</html>
