<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Video theo tháng – PolyOE</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<nav>
    <a class="brand" href="${pageContext.request.contextPath}/index.jsp">🎬 PolyOE</a>
    <a href="${pageContext.request.contextPath}/favorite-by-user">Bài 2.1 / 3.2</a>
    <a href="${pageContext.request.contextPath}/favorite-by-keyword">Bài 2.2 / 3.1</a>
    <a href="${pageContext.request.contextPath}/users-by-video">Bài 2.3</a>
    <a href="${pageContext.request.contextPath}/video-by-favorite">Bài 2.4</a>
    <a href="${pageContext.request.contextPath}/favorite-report">Bài 2.5</a>
    <a href="${pageContext.request.contextPath}/favorite-by-range">Bài 3.3</a>
    <a href="${pageContext.request.contextPath}/favorite-by-month" class="active">Bài 3.4</a>
    <a href="${pageContext.request.contextPath}/random-videos">Bài 4.1</a>
    <a href="${pageContext.request.contextPath}/report-by-year">Bài 4.2</a>
</nav>

<div class="container">
    <div class="page-title">Bài 3.4 – Video được thích theo tháng</div>
    <div class="page-subtitle">@NamedQuery: Video.findInMonths – IN (:months) với List&lt;Integer&gt;</div>

    <div class="card">
        <h2>🔍 Chọn các tháng</h2>
        <form method="get" action="${pageContext.request.contextPath}/favorite-by-month">
            <div class="months-row">
                <c:forEach begin="1" end="12" var="m">
                    <label class="month-cb">
                        <input type="checkbox" name="month" value="${m}"
                               <c:if test="${not empty months}">
                                   <c:forEach var="sel" items="${months}">
                                       <c:if test="${sel == m}">checked</c:if>
                                   </c:forEach>
                               </c:if>
                        >
                        Tháng ${m}
                    </label>
                </c:forEach>
            </div>
            <button type="submit" class="btn">Search</button>
        </form>
    </div>

    <c:if test="${not empty error}">
        <div class="alert alert-danger">${error}</div>
    </c:if>

    <c:if test="${not empty months}">
        <div class="card">
            <h2>🎬 Video được thích trong các tháng đã chọn</h2>
            <c:choose>
                <c:when test="${empty videos}">
                    <div class="empty-state">Không có video nào trong các tháng đã chọn.</div>
                </c:when>
                <c:otherwise>
                    <table>
                        <thead>
                            <tr><th>Id</th><th>Title</th><th>Views</th><th>Active?</th></tr>
                        </thead>
                        <tbody>
                            <c:forEach var="v" items="${videos}">
                                <tr>
                                    <td><code>${v.id}</code></td>
                                    <td>${v.title}</td>
                                    <td>${v.views}</td>
                                    <td>
                                        <span class="badge ${v.active ? 'badge-yes' : 'badge-no'}">
                                            ${v.active ? 'Yes' : 'No'}
                                        </span>
                                    </td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </c:otherwise>
            </c:choose>
        </div>
    </c:if>
</div>
</body>
</html>
