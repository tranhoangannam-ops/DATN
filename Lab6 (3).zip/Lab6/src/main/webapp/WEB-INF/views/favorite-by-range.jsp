<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Video theo khoảng ngày – PolyOE</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<nav>
    <a class="brand" href="${pageContext.request.contextPath}/index.jsp">🎬 PolyOE</a>
    <a href="${pageContext.request.contextPath}/favorite-by-user">Bài 2.1 / 3.2</a>
    <a href="${pageContext.request.contextPath}/favorite-by-keyword">Bài 2.2 / 3.1</a>
    <a href="${pageContext.request.contextPath}/users-by-video">Bài 2.3</a>
    <a href="${pageContext.request.contextPath}/video-by-favorite">Bài 2.4</a>
    <a href="${pageContext.request.contextPath}/favorite-report">Bài 2.5</a>
    <a href="${pageContext.request.contextPath}/favorite-by-range" class="active">Bài 3.3</a>
    <a href="${pageContext.request.contextPath}/favorite-by-month">Bài 3.4</a>
    <a href="${pageContext.request.contextPath}/random-videos">Bài 4.1</a>
    <a href="${pageContext.request.contextPath}/report-by-year">Bài 4.2</a>
</nav>

<div class="container">
    <div class="page-title">Bài 3.3 – Video được thích trong khoảng thời gian</div>
    <div class="page-subtitle">@NamedQuery: Video.findInRange – BETWEEN :min AND :max</div>

    <div class="card">
        <h2>🔍 Chọn khoảng ngày</h2>
        <form method="get" action="${pageContext.request.contextPath}/favorite-by-range">
            <div class="form-row">
                <input type="date" name="from" value="${fromStr}" required placeholder="From date?">
                <input type="date" name="to"   value="${toStr}"   required placeholder="To date?">
                <button type="submit" class="btn">Search</button>
            </div>
        </form>
    </div>

    <c:if test="${not empty error}">
        <div class="alert alert-danger">${error}</div>
    </c:if>

    <c:if test="${not empty fromStr}">
        <div class="card">
            <h2>🎬 Video được thích từ <strong>${fromStr}</strong> đến <strong>${toStr}</strong></h2>
            <c:choose>
                <c:when test="${empty videos}">
                    <div class="empty-state">Không có video nào trong khoảng thời gian này.</div>
                </c:when>
                <c:otherwise>
                    <table>
                        <thead>
                            <tr><th>Id</th><th>Title</th><th>Views</th><th>Active?</th></tr>
                        </thead>
                        <tbody>
                            <c:forEach var="v" items="${videos}">
                                <tr>
                                    <td><code>${v.id}</code></td>
                                    <td>${v.title}</td>
                                    <td>${v.views}</td>
                                    <td>
                                        <span class="badge ${v.active ? 'badge-yes' : 'badge-no'}">
                                            ${v.active ? 'Yes' : 'No'}
                                        </span>
                                    </td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </c:otherwise>
            </c:choose>
        </div>
    </c:if>
</div>
</body>
</html>
