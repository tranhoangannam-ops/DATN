<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Video yêu thích theo User – PolyOE</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<nav>
    <a class="brand" href="${pageContext.request.contextPath}/index.jsp">🎬 PolyOE</a>
    <a href="${pageContext.request.contextPath}/favorite-by-user" class="active">Bài 2.1 / 3.2</a>
    <a href="${pageContext.request.contextPath}/favorite-by-keyword">Bài 2.2 / 3.1</a>
    <a href="${pageContext.request.contextPath}/users-by-video">Bài 2.3</a>
    <a href="${pageContext.request.contextPath}/video-by-favorite">Bài 2.4</a>
    <a href="${pageContext.request.contextPath}/favorite-report">Bài 2.5</a>
    <a href="${pageContext.request.contextPath}/favorite-by-range">Bài 3.3</a>
    <a href="${pageContext.request.contextPath}/favorite-by-month">Bài 3.4</a>
    <a href="${pageContext.request.contextPath}/random-videos">Bài 4.1</a>
    <a href="${pageContext.request.contextPath}/report-by-year">Bài 4.2</a>
</nav>

<div class="container">
    <div class="page-title">Bài 2.1 / 3.2 – Video yêu thích theo người dùng</div>

    <%-- Form tìm kiếm --%>
    <div class="card">
        <h2>🔍 Tìm kiếm</h2>
        <form method="get" action="${pageContext.request.contextPath}/favorite-by-user">
            <div class="form-row">
                <input type="text" name="username" placeholder="Username?"
                       value="${username}" required>
                <select name="namedQuery">
                    <option value="false" ${mode == 'JPQL' ? 'selected' : ''}>Bài 2.1 – JPQL trực tiếp</option>
                    <option value="true"  ${mode == 'NamedQuery' ? 'selected' : ''}>Bài 3.2 – @NamedQuery</option>
                </select>
                <button type="submit" class="btn">Search</button>
            </div>
        </form>
    </div>

    <%-- Hiển thị lỗi --%>
    <c:if test="${not empty error}">
        <div class="alert alert-danger">${error}</div>
    </c:if>

    <%-- Hiển thị thông tin User --%>
    <c:if test="${not empty user}">
        <div class="card">
            <h2>👤 Thông tin người dùng</h2>
            <div class="info-box">
                <p><span class="label">Username:</span> ${user.id}</p>
                <p><span class="label">Fullname:</span> ${user.fullname}</p>
                <p><span class="label">Email:</span> ${user.email}</p>
                <p><span class="label">Role:</span>
                    <c:choose>
                        <c:when test="${user.admin}">
                            <span class="badge badge-admin">Admin</span>
                        </c:when>
                        <c:otherwise>
                            <span class="badge badge-yes">User</span>
                        </c:otherwise>
                    </c:choose>
                </p>
                <p><span class="label">Chế độ:</span>
                    <span style="color:#2f5f9e;font-weight:600">${mode}</span>
                </p>
            </div>
        </div>

        <%-- Bài 2.1: Dùng List<Favorite> --%>
        <c:if test="${mode == 'JPQL'}">
            <div class="card">
                <h2>🎬 Danh sách video yêu thích (qua Favorite.video)</h2>
                <c:choose>
                    <c:when test="${empty favorites}">
                        <div class="empty-state">Người dùng chưa có video yêu thích nào.</div>
                    </c:when>
                    <c:otherwise>
                        <table>
                            <thead>
                                <tr><th>Id</th><th>Title</th><th>Views</th><th>Active</th><th>Like Date</th></tr>
                            </thead>
                            <tbody>
                                <c:forEach var="fav" items="${favorites}">
                                    <tr>
                                        <td><code>${fav.video.id}</code></td>
                                        <td>${fav.video.title}</td>
                                        <td>${fav.video.views}</td>
                                        <td>
                                            <span class="badge ${fav.video.active ? 'badge-yes' : 'badge-no'}">
                                                ${fav.video.active ? 'Yes' : 'No'}
                                            </span>
                                        </td>
                                        <td><fmt:formatDate value="${fav.likeDate}" pattern="dd/MM/yyyy"/></td>
                                    </tr>
                                </c:forEach>
                            </tbody>
                        </table>
                    </c:otherwise>
                </c:choose>
            </div>
        </c:if>

        <%-- Bài 3.2: Dùng List<Video> từ NamedQuery --%>
        <c:if test="${mode == 'NamedQuery'}">
            <div class="card">
                <h2>🎬 Danh sách video yêu thích (@NamedQuery: Video.findByUser)</h2>
                <c:choose>
                    <c:when test="${empty videos}">
                        <div class="empty-state">Không tìm thấy video yêu thích.</div>
                    </c:when>
                    <c:otherwise>
                        <table>
                            <thead>
                                <tr><th>Id</th><th>Title</th><th>Views</th><th>Active</th></tr>
                            </thead>
                            <tbody>
                                <c:forEach var="v" items="${videos}">
                                    <tr>
                                        <td><code>${v.id}</code></td>
                                        <td>${v.title}</td>
                                        <td>${v.views}</td>
                                        <td>
                                            <span class="badge ${v.active ? 'badge-yes' : 'badge-no'}">
                                                ${v.active ? 'Yes' : 'No'}
                                            </span>
                                        </td>
                                    </tr>
                                </c:forEach>
                            </tbody>
                        </table>
                    </c:otherwise>
                </c:choose>
            </div>
        </c:if>
    </c:if>
</div>
</body>
</html>
