<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Báo cáo lượt thích – PolyOE</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<nav>
    <a class="brand" href="${pageContext.request.contextPath}/index.jsp">🎬 PolyOE</a>
    <a href="${pageContext.request.contextPath}/favorite-by-user">Bài 2.1 / 3.2</a>
    <a href="${pageContext.request.contextPath}/favorite-by-keyword">Bài 2.2 / 3.1</a>
    <a href="${pageContext.request.contextPath}/users-by-video">Bài 2.3</a>
    <a href="${pageContext.request.contextPath}/video-by-favorite">Bài 2.4</a>
    <a href="${pageContext.request.contextPath}/favorite-report" class="active">Bài 2.5</a>
    <a href="${pageContext.request.contextPath}/favorite-by-range">Bài 3.3</a>
    <a href="${pageContext.request.contextPath}/favorite-by-month">Bài 3.4</a>
    <a href="${pageContext.request.contextPath}/random-videos">Bài 4.1</a>
    <a href="${pageContext.request.contextPath}/report-by-year">Bài 4.2</a>
</nav>

<div class="container">
    <div class="page-title">Bài 2.5 – Tổng hợp lượt thích từng video</div>
    <div class="page-subtitle">JPQL: GROUP BY o.video.title + constructor new Report(...)</div>

    <c:if test="${not empty error}">
        <div class="alert alert-danger">${error}</div>
    </c:if>

    <div class="card">
        <h2>📊 Thống kê lượt thích (toàn thời gian)</h2>
        <c:choose>
            <c:when test="${empty reports}">
                <div class="empty-state">Chưa có dữ liệu yêu thích.</div>
            </c:when>
            <c:otherwise>
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Video Title</th>
                            <th>Favorite Count</th>
                            <th>Newest Date</th>
                            <th>Oldest Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:forEach var="r" items="${reports}" varStatus="st">
                            <tr>
                                <td>${st.index + 1}</td>
                                <td>${r.group}</td>
                                <td><strong>${r.likes}</strong></td>
                                <td><fmt:formatDate value="${r.newest}" pattern="dd/MM/yyyy"/></td>
                                <td><fmt:formatDate value="${r.oldest}" pattern="dd/MM/yyyy"/></td>
                            </tr>
                        </c:forEach>
                    </tbody>
                </table>
            </c:otherwise>
        </c:choose>
    </div>
</div>
</body>
</html>
