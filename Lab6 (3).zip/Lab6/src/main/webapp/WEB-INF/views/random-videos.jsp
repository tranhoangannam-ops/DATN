<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>10 Video ngẫu nhiên – PolyOE</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<nav>
    <a class="brand" href="${pageContext.request.contextPath}/index.jsp">🎬 PolyOE</a>
    <a href="${pageContext.request.contextPath}/favorite-by-user">Bài 2.1 / 3.2</a>
    <a href="${pageContext.request.contextPath}/favorite-by-keyword">Bài 2.2 / 3.1</a>
    <a href="${pageContext.request.contextPath}/users-by-video">Bài 2.3</a>
    <a href="${pageContext.request.contextPath}/video-by-favorite">Bài 2.4</a>
    <a href="${pageContext.request.contextPath}/favorite-report">Bài 2.5</a>
    <a href="${pageContext.request.contextPath}/favorite-by-range">Bài 3.3</a>
    <a href="${pageContext.request.contextPath}/favorite-by-month">Bài 3.4</a>
    <a href="${pageContext.request.contextPath}/random-videos" class="active">Bài 4.1</a>
    <a href="${pageContext.request.contextPath}/report-by-year">Bài 4.2</a>
</nav>

<div class="container">
    <div class="page-title">Bài 4.1 – 10 Video ngẫu nhiên (Native SQL)</div>
    <div class="page-subtitle">@NamedNativeQuery: SELECT TOP 10 * FROM Videos ORDER BY NEWID()</div>

    <div class="card" style="text-align:center">
        <a href="${pageContext.request.contextPath}/random-videos" class="btn">🔀 Tải lại ngẫu nhiên</a>
    </div>

    <c:if test="${not empty error}">
        <div class="alert alert-danger">${error}</div>
    </c:if>

    <div class="card">
        <h2>🎬 10 Video ngẫu nhiên</h2>
        <c:choose>
            <c:when test="${empty videos}">
                <div class="empty-state">Chưa có video nào trong CSDL.</div>
            </c:when>
            <c:otherwise>
                <table>
                    <thead>
                        <tr><th>#</th><th>Id</th><th>Title</th><th>Views</th><th>Active?</th></tr>
                    </thead>
                    <tbody>
                        <c:forEach var="v" items="${videos}" varStatus="st">
                            <tr>
                                <td>${st.index + 1}</td>
                                <td><code>${v.id}</code></td>
                                <td>${v.title}</td>
                                <td>${v.views}</td>
                                <td>
                                    <span class="badge ${v.active ? 'badge-yes' : 'badge-no'}">
                                        ${v.active ? 'Yes' : 'No'}
                                    </span>
                                </td>
                            </tr>
                        </c:forEach>
                    </tbody>
                </table>
            </c:otherwise>
        </c:choose>
    </div>
</div>
</body>
</html>
