<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Báo cáo theo năm – PolyOE</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<nav>
    <a class="brand" href="${pageContext.request.contextPath}/index.jsp">🎬 PolyOE</a>
    <a href="${pageContext.request.contextPath}/favorite-by-user">Bài 2.1 / 3.2</a>
    <a href="${pageContext.request.contextPath}/favorite-by-keyword">Bài 2.2 / 3.1</a>
    <a href="${pageContext.request.contextPath}/users-by-video">Bài 2.3</a>
    <a href="${pageContext.request.contextPath}/video-by-favorite">Bài 2.4</a>
    <a href="${pageContext.request.contextPath}/favorite-report">Bài 2.5</a>
    <a href="${pageContext.request.contextPath}/favorite-by-range">Bài 3.3</a>
    <a href="${pageContext.request.contextPath}/favorite-by-month">Bài 3.4</a>
    <a href="${pageContext.request.contextPath}/random-videos">Bài 4.1</a>
    <a href="${pageContext.request.contextPath}/report-by-year" class="active">Bài 4.2</a>
</nav>

<div class="container">
    <div class="page-title">Bài 4.2 – Tổng hợp lượt thích theo năm</div>
    <div class="page-subtitle">Stored Procedure: spFavoriteByYear(@Year INT)</div>

    <div class="card">
        <h2>🔍 Chọn năm</h2>
        <form method="get" action="${pageContext.request.contextPath}/report-by-year">
            <div class="form-row">
                <input type="number" name="year" placeholder="Năm (vd: 2024)"
                       value="${year}" min="2000" max="2099" required>
                <button type="submit" class="btn">Search</button>
            </div>
        </form>
    </div>

    <c:if test="${not empty error}">
        <div class="alert alert-danger">${error}</div>
    </c:if>

    <c:if test="${not empty year}">
        <div class="card">
            <h2>📊 Thống kê lượt thích năm <strong>${year}</strong></h2>
            <c:choose>
                <c:when test="${empty reports}">
                    <div class="empty-state">Không có dữ liệu yêu thích trong năm ${year}.</div>
                </c:when>
                <c:otherwise>
                    <table>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Title</th>
                                <th>Favorite Count</th>
                                <th>Newest Date</th>
                                <th>Oldest Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach var="r" items="${reports}" varStatus="st">
                                <tr>
                                    <td>${st.index + 1}</td>
                                    <td>${r.group}</td>
                                    <td><strong>${r.likes}</strong></td>
                                    <td><fmt:formatDate value="${r.newest}" pattern="dd/MM/yyyy"/></td>
                                    <td><fmt:formatDate value="${r.oldest}" pattern="dd/MM/yyyy"/></td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </c:otherwise>
            </c:choose>
        </div>
    </c:if>
</div>
</body>
</html>
