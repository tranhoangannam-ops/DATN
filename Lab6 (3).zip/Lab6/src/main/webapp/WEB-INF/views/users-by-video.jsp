<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Users thích Video – PolyOE</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<nav>
    <a class="brand" href="${pageContext.request.contextPath}/index.jsp">🎬 PolyOE</a>
    <a href="${pageContext.request.contextPath}/favorite-by-user">Bài 2.1 / 3.2</a>
    <a href="${pageContext.request.contextPath}/favorite-by-keyword">Bài 2.2 / 3.1</a>
    <a href="${pageContext.request.contextPath}/users-by-video" class="active">Bài 2.3</a>
    <a href="${pageContext.request.contextPath}/video-by-favorite">Bài 2.4</a>
    <a href="${pageContext.request.contextPath}/favorite-report">Bài 2.5</a>
    <a href="${pageContext.request.contextPath}/favorite-by-range">Bài 3.3</a>
    <a href="${pageContext.request.contextPath}/favorite-by-month">Bài 3.4</a>
    <a href="${pageContext.request.contextPath}/random-videos">Bài 4.1</a>
    <a href="${pageContext.request.contextPath}/report-by-year">Bài 4.2</a>
</nav>

<div class="container">
    <div class="page-title">Bài 2.3 – Người dùng thích video</div>

    <div class="card">
        <h2>🔍 Nhập Video Id</h2>
        <form method="get" action="${pageContext.request.contextPath}/users-by-video">
            <div class="form-row">
                <input type="text" name="videoId" placeholder="Video Id? (vd: VID00000001)"
                       value="${videoId}" required>
                <button type="submit" class="btn">Search</button>
            </div>
        </form>
    </div>

    <c:if test="${not empty error}">
        <div class="alert alert-danger">${error}</div>
    </c:if>

    <c:if test="${not empty videoId}">
        <div class="card">
            <h2>👥 Người dùng đã thích video: <code>${videoId}</code></h2>
            <c:choose>
                <c:when test="${empty users}">
                    <div class="empty-state">Chưa có người dùng nào thích video này.</div>
                </c:when>
                <c:otherwise>
                    <table>
                        <thead>
                            <tr><th>Username</th><th>Fullname</th><th>Email</th><th>Role</th></tr>
                        </thead>
                        <tbody>
                            <c:forEach var="u" items="${users}">
                                <tr>
                                    <td><code>${u.id}</code></td>
                                    <td>${u.fullname}</td>
                                    <td>${u.email}</td>
                                    <td>
                                        <span class="badge ${u.admin ? 'badge-admin' : 'badge-yes'}">
                                            ${u.admin ? 'Admin' : 'User'}
                                        </span>
                                    </td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </c:otherwise>
            </c:choose>
        </div>
    </c:if>
</div>
</body>
</html>
