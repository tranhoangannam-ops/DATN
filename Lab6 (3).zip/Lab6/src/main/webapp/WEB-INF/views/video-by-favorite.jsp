<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Video có/không Favorite – PolyOE</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<nav>
    <a class="brand" href="${pageContext.request.contextPath}/index.jsp">🎬 PolyOE</a>
    <a href="${pageContext.request.contextPath}/favorite-by-user">Bài 2.1 / 3.2</a>
    <a href="${pageContext.request.contextPath}/favorite-by-keyword">Bài 2.2 / 3.1</a>
    <a href="${pageContext.request.contextPath}/users-by-video">Bài 2.3</a>
    <a href="${pageContext.request.contextPath}/video-by-favorite" class="active">Bài 2.4</a>
    <a href="${pageContext.request.contextPath}/favorite-report">Bài 2.5</a>
    <a href="${pageContext.request.contextPath}/favorite-by-range">Bài 3.3</a>
    <a href="${pageContext.request.contextPath}/favorite-by-month">Bài 3.4</a>
    <a href="${pageContext.request.contextPath}/random-videos">Bài 4.1</a>
    <a href="${pageContext.request.contextPath}/report-by-year">Bài 4.2</a>
</nav>

<div class="container">
    <div class="page-title">Bài 2.4 – Video có / không có yêu thích</div>

    <div class="card">
        <h2>🔍 Chọn loại hiển thị</h2>
        <form method="get" action="${pageContext.request.contextPath}/video-by-favorite">
            <div class="radio-row">
                <label>
                    <input type="radio" name="favorite" value="true"
                           ${favorite == true ? 'checked' : ''}>
                    ❤️ Có Favorite (IS NOT EMPTY)
                </label>
                <label>
                    <input type="radio" name="favorite" value="false"
                           ${favorite == false && favorite != null ? 'checked' : ''}>
                    🚫 Không có Favorite (IS EMPTY)
                </label>
                <button type="submit" class="btn">Search</button>
            </div>
        </form>
    </div>

    <c:if test="${not empty error}">
        <div class="alert alert-danger">${error}</div>
    </c:if>

    <c:if test="${favorite != null}">
        <div class="card">
            <h2>🎬 Video
                <c:choose>
                    <c:when test="${favorite}">❤️ đã được yêu thích</c:when>
                    <c:otherwise>🚫 chưa được yêu thích</c:otherwise>
                </c:choose>
            </h2>
            <c:choose>
                <c:when test="${empty videos}">
                    <div class="empty-state">Không có video nào.</div>
                </c:when>
                <c:otherwise>
                    <table>
                        <thead>
                            <tr><th>Id</th><th>Title</th><th>Views</th><th>Active?</th></tr>
                        </thead>
                        <tbody>
                            <c:forEach var="v" items="${videos}">
                                <tr>
                                    <td><code>${v.id}</code></td>
                                    <td>${v.title}</td>
                                    <td>${v.views}</td>
                                    <td>
                                        <span class="badge ${v.active ? 'badge-yes' : 'badge-no'}">
                                            ${v.active ? 'Yes' : 'No'}
                                        </span>
                                    </td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </c:otherwise>
            </c:choose>
        </div>
    </c:if>
</div>
</body>
</html>
