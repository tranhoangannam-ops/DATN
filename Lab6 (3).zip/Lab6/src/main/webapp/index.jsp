<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PolyOE – Lab 06</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<nav>
    <a class="brand" href="index.jsp">🎬 PolyOE</a>
    <a href="favorite-by-user">Bài 2.1 – Yêu thích theo User</a>
    <a href="favorite-by-keyword">Bài 2.2 – Tìm theo Keyword</a>
    <a href="users-by-video">Bài 2.3 – Users theo Video</a>
    <a href="video-by-favorite">Bài 2.4 – Video có/không Favorite</a>
    <a href="favorite-report">Bài 2.5 – Báo cáo lượt thích</a>
    <a href="favorite-by-range">Bài 3.3 – Theo khoảng ngày</a>
    <a href="favorite-by-month">Bài 3.4 – Theo tháng</a>
    <a href="random-videos">Bài 4.1 – 10 Video ngẫu nhiên</a>
    <a href="report-by-year">Bài 4.2 – Báo cáo theo năm (SP)</a>
</nav>

<div class="container">
    <div class="page-title">Lab 06 – JPA Thực Thể Kết Hợp</div>
    <div class="page-subtitle">FPT Polytechnic – Tomcat 11 · JDK 21 · Hibernate 6 · SQL Server</div>

    <div class="card">
        <h2>📋 Danh sách bài thực hành</h2>
        <table>
            <thead>
                <tr><th>Bài</th><th>Nội dung</th><th>Kỹ thuật</th><th>Link</th></tr>
            </thead>
            <tbody>
                <tr>
                    <td>Bài 1</td>
                    <td>Ánh xạ thực thể kết hợp (Entity Mapping)</td>
                    <td>@Entity, @OneToMany, @ManyToOne, @UniqueConstraint</td>
                    <td>–</td>
                </tr>
                <tr>
                    <td>Bài 2.1</td>
                    <td>Video yêu thích theo người dùng</td>
                    <td>em.find() + getFavorites()</td>
                    <td><a href="favorite-by-user">Truy cập</a></td>
                </tr>
                <tr>
                    <td>Bài 2.2</td>
                    <td>Video yêu thích theo từ khóa</td>
                    <td>JPQL LIKE</td>
                    <td><a href="favorite-by-keyword">Truy cập</a></td>
                </tr>
                <tr>
                    <td>Bài 2.3</td>
                    <td>Người dùng thích video (nhập video id)</td>
                    <td>JPQL SELECT o.user</td>
                    <td><a href="users-by-video">Truy cập</a></td>
                </tr>
                <tr>
                    <td>Bài 2.4</td>
                    <td>Video có / không có yêu thích</td>
                    <td>JPQL IS EMPTY / IS NOT EMPTY</td>
                    <td><a href="video-by-favorite">Truy cập</a></td>
                </tr>
                <tr>
                    <td>Bài 2.5</td>
                    <td>Tổng hợp lượt thích từng video</td>
                    <td>JPQL GROUP BY + constructor new Report()</td>
                    <td><a href="favorite-report">Truy cập</a></td>
                </tr>
                <tr>
                    <td>Bài 3.1</td>
                    <td>@NamedQuery tìm theo keyword</td>
                    <td>createNamedQuery("Video.findByKeyword")</td>
                    <td><a href="favorite-by-keyword">Truy cập</a></td>
                </tr>
                <tr>
                    <td>Bài 3.2</td>
                    <td>@NamedQuery tìm theo user</td>
                    <td>createNamedQuery("Video.findByUser")</td>
                    <td><a href="favorite-by-user">Truy cập</a></td>
                </tr>
                <tr>
                    <td>Bài 3.3</td>
                    <td>Video được thích trong khoảng ngày</td>
                    <td>@NamedQuery BETWEEN</td>
                    <td><a href="favorite-by-range">Truy cập</a></td>
                </tr>
                <tr>
                    <td>Bài 3.4</td>
                    <td>Video được thích theo tháng</td>
                    <td>@NamedQuery IN (List&lt;Integer&gt;)</td>
                    <td><a href="favorite-by-month">Truy cập</a></td>
                </tr>
                <tr>
                    <td>Bài 4.1</td>
                    <td>10 video ngẫu nhiên</td>
                    <td>@NamedNativeQuery – SELECT TOP 10 … NEWID()</td>
                    <td><a href="random-videos">Truy cập</a></td>
                </tr>
                <tr>
                    <td>Bài 4.2</td>
                    <td>Tổng hợp lượt thích theo năm</td>
                    <td>@NamedStoredProcedureQuery – spFavoriteByYear</td>
                    <td><a href="report-by-year">Truy cập</a></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
